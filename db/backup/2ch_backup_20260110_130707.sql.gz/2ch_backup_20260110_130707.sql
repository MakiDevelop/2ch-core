--
-- PostgreSQL database dump
--

\restrict kwU3nWojI4L7Wht4tmMmGMwM9OD4RikUudKcLKsAHe7NxTpwv4tXft9sxEaO8Ab

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: boards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boards (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.boards OWNER TO postgres;

--
-- Name: boards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.boards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.boards_id_seq OWNER TO postgres;

--
-- Name: boards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.boards_id_seq OWNED BY public.boards.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id bigint NOT NULL,
    content text NOT NULL,
    status smallint DEFAULT 0 NOT NULL,
    ip_hash character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    parent_id bigint,
    board_id integer
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: boards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boards ALTER COLUMN id SET DEFAULT nextval('public.boards_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Data for Name: boards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boards (id, slug, name, description, display_order, is_active, created_at) FROM stdin;
1	chat	雜談	任何無法分類、也不想分類的話題入口。此板的存在目的是保護其他所有板。	1	t	2026-01-10 04:50:41.46994
2	news	時事	新聞、政治、社會事件與公共議題。高衝突、高流量，必須集中處理。	2	t	2026-01-10 04:50:41.46994
3	question	問卦	低門檻提問、求解、請益。用來避免雜談板被問題洗版。	3	t	2026-01-10 04:50:41.46994
4	rant	抱怨	發洩情緒、負面經驗、不滿與牢騷。此板不存在，其他板一定會爆。	4	t	2026-01-10 04:50:41.46994
5	acg	ACG	動畫、漫畫、遊戲、影視、追星與流行文化。	5	t	2026-01-10 04:50:41.46994
6	tech	科技	程式、AI、3C、網路文化與科技趨勢。	6	t	2026-01-10 04:50:41.46994
7	life	生活	工作、感情、家庭、日常瑣事與人生觀察。	7	t	2026-01-10 04:50:41.46994
8	nsfw	成人	成人內容集中處理，避免污染其他板。	8	t	2026-01-10 04:50:41.46994
9	controversy	爭議	容易引戰、價值衝突、高對立話題的集中區。此板的目的在於「隔離」，而非鼓勵。	9	t	2026-01-10 04:50:41.46994
10	other	其他	系統測試、臨時導流、或尚未確定去向的話題。	10	t	2026-01-10 04:50:41.46994
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, content, status, ip_hash, created_at, parent_id, board_id) FROM stdin;
1	Hello 2ch.tw 👋 這是第一篇匿名貼文	0	dev-test-hash	2026-01-03 13:36:33.737497+00	\N	1
2	我的第一篇 2ch.tw 匿名貼文	0	api-dev-hash	2026-01-03 13:40:50.575446+00	\N	1
3	Guard 測試：正常貼文	0	api-dev-hash	2026-01-03 13:53:15.189104+00	\N	1
4	第一次	0	api-dev-hash	2026-01-03 13:53:28.276936+00	\N	1
5	ipHash 真實化測試	0	eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3	2026-01-03 14:29:04.076282+00	\N	1
6	Thread 測試	0	eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3	2026-01-03 14:36:30.813027+00	\N	1
7	這是回覆	0	eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3	2026-01-03 14:36:49.965827+00	1	1
14	这是一个测试主题，准备被删除	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:57:21.04638+00	\N	1
8	这是一个测试主题	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:47:49.26287+00	\N	1
9	这是第 1 条回复	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:48:00.993843+00	8	1
10	这是第 2 条回复	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:48:18.379956+00	8	1
11	这是第 3 条回复	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:48:34.116752+00	8	1
12	AI 技术的未来发展趋势讨论	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:52:51.102704+00	\N	6
13	推荐最近好看的动漫	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:53:06.978643+00	\N	5
15	这是一个测试主题，准备被锁定	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:57:45.919584+00	\N	1
16	测试批量删除 1	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:58:27.499457+00	\N	1
17	测试批量删除 2	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:58:38.539748+00	\N	1
18	测试批量删除 3	2	ddf72b6676cb429c9adf5335634fdb407bf3319e34499d9bc34885053678af4c	2026-01-10 04:58:49.578091+00	\N	1
\.


--
-- Name: boards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.boards_id_seq', 20, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 18, true);


--
-- Name: boards boards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_pkey PRIMARY KEY (id);


--
-- Name: boards boards_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_slug_key UNIQUE (slug);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: idx_boards_display_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_boards_display_order ON public.boards USING btree (display_order);


--
-- Name: idx_boards_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_boards_slug ON public.boards USING btree (slug);


--
-- Name: idx_posts_board_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_board_id ON public.posts USING btree (board_id);


--
-- Name: idx_posts_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_created_at ON public.posts USING btree (created_at DESC);


--
-- Name: idx_posts_created_at_desc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_created_at_desc ON public.posts USING btree (created_at DESC);


--
-- Name: posts posts_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id);


--
-- PostgreSQL database dump complete
--

\unrestrict kwU3nWojI4L7Wht4tmMmGMwM9OD4RikUudKcLKsAHe7NxTpwv4tXft9sxEaO8Ab

